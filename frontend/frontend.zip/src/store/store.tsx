import { createContext, useState } from "react";

const initState = {
    cart: 0,
    updateCart: ({item, action}:any)=>{}
}

const CartContext = createContext(initState)

const CartProvider = ({children}:any) =>{
    const [cart, setCart] = useState()

    const updateCart = ({item, action}:any) =>{
        console.log(cart)
        setCart((prev:any) => {

            if(action == 'add'){
                if (!prev) return [{...item}]
                return [
                    ...prev,
                    {...item}
                ]
            }
            
        })
    }
    return (
        <CartContext.Provider value={{ cart, updateCart }}>
            {children}
        </CartContext.Provider>
    );
}

export {CartContext, CartProvider}
