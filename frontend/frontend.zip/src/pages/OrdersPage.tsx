
const OrdersPage = () => {

    return (
        <>Orders</>
    )
}


export default OrdersPage