
export interface PaginationMeta{
    total: number,
    limit: number,
    offset: number
}